import os
import json
import logging
import nltk
from nltk.tokenize import sent_tokenize
import numpy as np
from llm_handler import LLMHandler
from pdf_processor import get_pdf_processor

try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

logger = logging.getLogger(__name__)

class SafetyProcessor:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.pdf_processor = get_pdf_processor()
        self.pdf_processor.process_pdf_directory()
        self.llm_handler = LLMHandler()
        self.emergency_guidebook = self._load_emergency_guidebook()
        self.incident_reports = self._load_incident_reports()
        logger.info("SafetyProcessor initialized.")

    def _load_emergency_guidebook(self):
        try:
            with open('data/pdfs/emergency_guidebook.json', 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            guidebook_data = {"hazardous_materials": []}
            os.makedirs('data/pdfs', exist_ok=True)
            with open('data/pdfs/emergency_guidebook.json', 'w') as f:
                json.dump(guidebook_data, f, indent=2)
            return guidebook_data

    def _load_incident_reports(self):
        try:
            with open('data/pdfs/incident_reports.json', 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            incident_data = {"incidents": []}
            os.makedirs('data/pdfs', exist_ok=True)
            with open('data/pdfs/incident_reports.json', 'w') as f:
                json.dump(incident_data, f, indent=2)
            return incident_data

    def retrieve_documents(self, query_info):
        results = []
        query_text = ""
        if "tokens" in query_info and query_info["tokens"]:
            query_text = " ".join(query_info["tokens"])
        elif "original_query" in query_info:
            query_text = query_info["original_query"]
        if query_text:
            pdf_results = self.pdf_processor.search(query_text, top_n=5)
            for pdf_result in pdf_results:
                doc_id = pdf_result["id"]
                text_chunk = self.pdf_processor.get_text_chunk(doc_id)
                results.append({
                    "source": "PDF Document",
                    "doc_type": pdf_result.get("document_type"),
                    "id": pdf_result.get("id"),
                    "title": pdf_result.get("title"),
                    "content": text_chunk,
                    "relevance_score": pdf_result.get("score", 0.8),
                    "filepath": pdf_result.get("filepath")
                })
        for material in self.emergency_guidebook.get("hazardous_materials", []):
            if any(keyword in material.get("name", "").lower() for keyword in query_info.get("tokens", [])):
                results.append({
                    "source": "Emergency Guidebook",
                    "title": material.get("name"),
                    "content": material.get("description"),
                    "protocols": material.get("protocols"),
                    "emergency_response": material.get("emergency_response"),
                    "relevance_score": 0.7
                })
        for incident in self.incident_reports.get("incidents", []):
            if any(keyword in incident.get("title", "").lower() for keyword in query_info.get("tokens", [])):
                results.append({
                    "source": "Incident Report",
                    "id": incident.get("id"),
                    "title": incident.get("title"),
                    "description": incident.get("description"),
                    "date": incident.get("date"),
                    "hazard_type": incident.get("hazard_type"),
                    "severity": incident.get("severity"),
                    "resolution": incident.get("resolution"),
                    "relevance_score": 0.6
                })
        results.sort(key=lambda x: x["relevance_score"], reverse=True)
        return results

    def generate_contextual_answer(self, query, results):
        if not results:
            return "No relevant safety information found."
        top_results = results[:3]
        prompt = f"User query: {query}\n\nProvide a detailed response with protocols, procedures, and incident information."
        context = top_results
        response = self.llm_handler.generate_response(prompt, context)
        if response and response.strip():
            return response
        fallback = "Based on available data, please refer to safety protocols and guidelines."
        return fallback

    def search_pdf_documents(self, query, top_n=3):
        return self.pdf_processor.search(query, top_n=top_n)

    def generate_chat_response(self, message, intent):
        pdf_context = self.search_pdf_documents(message)
        structured_context = []
        if intent == "emergency_protocol":
            for material in self.emergency_guidebook.get("hazardous_materials", []):
                if any(keyword in material.get("name", "").lower() for keyword in message.lower().split()):
                    structured_context.append(material)
        elif intent == "incident_inquiry":
            for incident in self.incident_reports.get("incidents", []):
                if any(keyword in incident.get("title", "").lower() for keyword in message.lower().split()):
                    structured_context.append(incident)
        all_context = pdf_context + structured_context
        prompt = f"User query: {message}\nIntent: {intent}\nProvide detailed safety information."
        llm_response = self.llm_handler.generate_response(prompt, all_context)
        if not llm_response or not llm_response.strip():
            if intent == "emergency_protocol" and structured_context:
                material = structured_context[0]
                protocols = "\n- " + "\n- ".join(material.get("protocols", []))
                return f"Emergency protocols for {material.get('name')}: {protocols}\nEmergency response: {material.get('emergency_response')}"
            elif intent == "incident_inquiry" and structured_context:
                incident = structured_context[0]
                return f"Similar incident: {incident.get('title')} (ID: {incident.get('id')})\nDescription: {incident.get('description')}\nResolution: {incident.get('resolution')}"
            else:
                return "I'm your safety assistant. Please provide more details."
        return llm_response

def get_safety_processor():
    return SafetyProcessor()
