import re
import logging
import nltk
logger = logging.getLogger(__name__)
try:
    nltk.download('punkt', quiet=True)
    nltk.download('stopwords', quiet=True)
    nltk.download('wordnet', quiet=True)
    from nltk.corpus import stopwords
    from nltk.tokenize import word_tokenize
    from nltk.stem import WordNetLemmatizer
    NLTK_AVAILABLE = True
except Exception as e:
    NLTK_AVAILABLE = False

STOPWORDS = {'a', 'an', 'the', 'and', 'or', 'but'}

class NLPEngine:
    def __init__(self):
        if NLTK_AVAILABLE:
            self.stop_words = set(stopwords.words('english'))
            self.lemmatizer = WordNetLemmatizer()
        else:
            self.stop_words = STOPWORDS
            self.lemmatizer = lambda word: word
        self.intent_patterns = {
            'emergency_protocol': [r'protocol.*emergency'],
            'incident_inquiry': [r'incident.*'],
            'risk_assessment': [r'risk.*']
        }
    def process_query(self, query):
        tokens = word_tokenize(query.lower()) if NLTK_AVAILABLE else query.lower().split()
        tokens = [t for t in tokens if t not in self.stop_words]
        lemmas = [self.lemmatizer.lemmatize(t) for t in tokens]
        intent = self._determine_intent(query)
        return {"original_query": query, "tokens": lemmas, "intent": intent}
    def _determine_intent(self, query):
        for intent, patterns in self.intent_patterns.items():
            for pattern in patterns:
                if re.search(pattern, query, re.IGNORECASE):
                    return intent
        return "general_inquiry"
    def extract_intent(self, message):
        return self._determine_intent(message)
