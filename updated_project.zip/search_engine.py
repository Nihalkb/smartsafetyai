import logging
import json
import re
from collections import Counter
from models import SafetyDocument, IncidentReport
logger = logging.getLogger(__name__)

def _tokenize_text(text):
    return re.findall(r'\b\w+\b', text.lower())

def initialize_search_index():
    # Updated to load from data/pdfs directory
    safety_documents = []
    incident_reports = []
    try:
        with open('data/pdfs/safety_documents.json', 'r') as f:
            safety_documents = json.load(f)
    except Exception as e:
        logger.warning("Could not load safety_documents.json.")
    try:
        with open('data/pdfs/incident_reports.json', 'r') as f:
            incident_reports = json.load(f)
    except Exception as e:
        logger.warning("Could not load incident_reports.json.")
    return safety_documents, incident_reports

def search_documents(query, top_n=5):
    safety_docs, incident_reports = initialize_search_index()
    results = []
    query_tokens = set(_tokenize_text(query))
    token_counts = Counter(_tokenize_text(query))
    for doc in safety_docs:
        doc_tokens = set(_tokenize_text(doc.get("content", "")))
        common = query_tokens.intersection(doc_tokens)
        if common:
            score = sum(token_counts[t] for t in common) / len(query_tokens)
            results.append({
                "id": doc.get("id"),
                "title": doc.get("title"),
                "content": doc.get("content")[:200] + "..." if len(doc.get("content", "")) > 200 else doc.get("content"),
                "document_type": doc.get("document_type"),
                "score": score
            })
    for incident in incident_reports:
        doc_tokens = set(_tokenize_text(incident.get("description", "")))
        common = query_tokens.intersection(doc_tokens)
        if common:
            score = sum(token_counts[t] for t in common) / len(query_tokens)
            results.append({
                "id": incident.get("id"),
                "title": incident.get("title"),
                "content": incident.get("description")[:200] + "..." if len(incident.get("description", "")) > 200 else incident.get("description"),
                "document_type": "incident",
                "score": score
            })
    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:top_n]
