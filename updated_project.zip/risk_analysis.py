import logging
import numpy as np
from datetime import datetime, timedelta
from models import IncidentReport
from sqlalchemy import func

logger = logging.getLogger(__name__)

def categorize_risk(incidents):
    categorized = {'Low': [], 'Medium': [], 'High': [], 'Critical': []}
    for incident in incidents:
        severity = incident.severity if incident.severity else 1
        if severity <= 2:
            categorized['Low'].append(incident)
        elif severity == 3:
            categorized['Medium'].append(incident)
        elif severity == 4:
            categorized['High'].append(incident)
        else:
            categorized['Critical'].append(incident)
    result = {"categories": {}, "total_count": len(incidents)}
    for level, items in categorized.items():
        result["categories"][level] = {"count": len(items), "incidents": items[:5]}
    return result

def predict_risk():
    try:
        one_year_ago = datetime.now() - timedelta(days=365)
        recent_incidents = IncidentReport.query.filter(IncidentReport.date_occurred >= one_year_ago).all()
        if not recent_incidents:
            return {"message": "Not enough historical data", "predictions": []}
        from collections import Counter
        locations = [inc.location for inc in recent_incidents if inc.location]
        location_counts = Counter(locations)
        high_risk_locations = [{"location": loc, "incident_count": count, "risk_level": "High" if count>=3 else "Medium"}
                               for loc, count in location_counts.items() if count > 1]
        return {"high_risk_locations": high_risk_locations, "prediction_date": datetime.now().strftime('%Y-%m-%d')}
    except Exception as e:
        logger.error(f"Error in risk prediction: {e}")
        return {"message": str(e), "predictions": []}
