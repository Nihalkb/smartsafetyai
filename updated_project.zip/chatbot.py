import logging
import random
import re
import spacy
from search_engine import search_documents
from pdf_processor import get_pdf_processor

try:
    from advanced_nlp import get_advanced_nlp
    HAS_ADVANCED_NLP = True
    logging.info("Using advanced NLP for chatbot.")
except ImportError:
    HAS_ADVANCED_NLP = False
    logging.warning("Advanced NLP not available, using basic NLP.")

try:
    nlp = spacy.load("en_core_web_sm")
except Exception:
    import os
    os.system("python -m spacy download en_core_web_sm")
    import spacy
    nlp = spacy.load("en_core_web_sm")

SAFETY_KEYWORDS = ["emergency", "protocol", "safety", "incident", "hazard", "risk", "fire", "spill", "ppe"]

INTENT_PATTERNS = {
    'protocol_search': [r'(protocol|procedure).*?(for|about)\s+(.+)'],
    'incident_query': [r'(incident|accident).*?(involving|about)\s+(.+)'],
    'risk_assessment': [r'(risk|danger).*'],
    'emergency_response': [r'(emergency|response).*'],
    'greeting': [r'^(hi|hello|hey)\b'],
    'goodbye': [r'^(bye|goodbye)\b'],
    'thanks': [r'^(thanks|thank you)\b'],
    'help': [r'^(help|assist)\b']
}

RESPONSE_TEMPLATES = {
    'greeting': ["Hello, how can I help you with safety information?"],
    'goodbye': ["Goodbye! Stay safe."],
    'thanks': ["You're welcome!"],
    'help': ["I can help with safety protocols, incident reports, and risk assessments."]
}

def identify_intent(message):
    message_lower = message.lower()
    for intent, patterns in INTENT_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, message_lower):
                return intent
    doc = nlp(message)
    for token in doc:
        if token.text.lower() in SAFETY_KEYWORDS:
            return 'protocol_search'
    return 'unknown'

def process_chat_message(message):
    intent = identify_intent(message)
    if intent in RESPONSE_TEMPLATES:
        return random.choice(RESPONSE_TEMPLATES[intent])
    response = "I have found the following information: \n"
    results = search_documents(message, top_n=3)
    for i, res in enumerate(results, 1):
        response += f"{i}. {res['title']}: {res.get('content', '')[:150]}...\n"
    response += "Would you like more details?"
    return response
