import os
import logging
import time
from openai import OpenAI

logger = logging.getLogger(__name__)

class LLMHandler:
    def __init__(self):
        self.token = os.environ.get("LLMFOUNDRY_TOKEN")
        if not self.token:
            logger.error("LLMFOUNDRY_TOKEN not set in environment")
            self.client = None
        else:
            try:
                self.client = OpenAI(
                    api_key=f"{self.token}:my-test-project",
                    base_url="https://llmfoundry.straive.com/openai/v1/",
                )
                logger.info("LLM Foundry client initialized.")
            except Exception as e:
                logger.error(f"Error initializing LLM Foundry client: {e}")
                self.client = None
        self.cache = {}
        self.cache_ttl = 3600
        self.model = "gpt-4o-mini"

    def _clean_cache(self):
        current_time = time.time()
        keys_to_delete = [k for k,v in self.cache.items() if current_time - v["timestamp"] > self.cache_ttl]
        for k in keys_to_delete:
            del self.cache[k]

    def generate_response(self, prompt, context=None, max_length=250):
        self._clean_cache()
        cache_key = f"{prompt}_{str(context)}"
        if cache_key in self.cache:
            logger.info("Returning cached response.")
            return self.cache[cache_key]["response"]
        if not self.client:
            logger.error("No LLM client available.")
            return "LLM client not available."
        try:
            messages = [{"role": "system", "content": "You are a safety information assistant."}]
            if context:
                messages.append({"role": "system", "content": str(context)})
            messages.append({"role": "user", "content": prompt})
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=max_length,
                temperature=0.5,
            )
            generated_text = response.choices[0].message.content
            self.cache[cache_key] = {"response": generated_text, "timestamp": time.time()}
            return generated_text
        except Exception as e:
            logger.error(f"Error generating response: {e}")
            return "Error generating response."

    def analyze_sentiment(self, text):
        if not self.client:
            return {"rating": 3, "confidence": 0.5}
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "Analyze sentiment and return JSON with keys 'rating' and 'confidence'."},
                    {"role": "user", "content": text},
                ]
            )
            import json
            result = json.loads(response.choices[0].message.content)
            return {"rating": result.get("rating", 3), "confidence": result.get("confidence", 0.5)}
        except Exception as e:
            logger.error(f"Sentiment analysis error: {e}")
            return {"rating": 3, "confidence": 0.5}
