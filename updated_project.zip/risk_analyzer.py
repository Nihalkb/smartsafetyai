import re
import logging
import random
from datetime import datetime
logger = logging.getLogger(__name__)

class RiskAnalyzer:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.severity_criteria = {
            'keywords': {
                'severe': ['severe', 'critical', 'explosion'],
                'high': ['high', 'serious', 'fire'],
                'medium': ['medium', 'spill', 'leak'],
                'low': ['low', 'minor']
            },
            'hazard_severity': {
                'toxic gases': 5,
                'flammable gases': 4,
                'corrosive materials': 4,
                'flammable liquids': 3,
                'non hazardous': 1
            }
        }
        self.severity_levels = {
            1: "Minimal Risk",
            2: "Low Risk",
            3: "Moderate Risk",
            4: "High Risk",
            5: "Critical Risk"
        }
        self.logger.info("RiskAnalyzer initialized.")

    def assess_severity(self, incident_details):
        severity = 3
        evidence = []
        for level, keywords in self.severity_criteria['keywords'].items():
            for keyword in keywords:
                if re.search(r'\b' + re.escape(keyword) + r'\b', incident_details, re.IGNORECASE):
                    evidence.append(f"Found keyword '{keyword}' indicating {level} severity.")
                    if level == 'severe':
                        severity += 2
                    elif level == 'high':
                        severity += 1
                    elif level == 'low':
                        severity -= 1
        for hazard, base in self.severity_criteria['hazard_severity'].items():
            if re.search(r'\b' + re.escape(hazard) + r'\b', incident_details, re.IGNORECASE):
                evidence.append(f"Involves '{hazard}' with base severity {base}.")
                severity = max(severity, base)
        severity = max(1, min(5, severity))
        rationale = "Risk assessment rationale:\n" + "\n".join(evidence) + f"\nFinal severity: {severity}/5 - {self.severity_levels[severity]}"
        return severity, rationale

    def generate_predictive_insights(self, incident_details, severity):
        insights = []
        if severity >= 4:
            insights.append("High risk incident, recommend immediate action.")
        elif severity == 3:
            insights.append("Moderate risk, review procedures.")
        else:
            insights.append("Low risk, monitor the situation.")
        insights.append("Predictive insight: Regular maintenance can reduce recurrence.")
        formatted_insights = "Predictive Insights:\n" + "\n".join(f"• {insight}" for insight in insights)
        return formatted_insights
