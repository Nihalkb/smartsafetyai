import logging
from safety_processor import SafetyProcessor
from nlp_engine import NLPEngine

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_chat_responses():
    nlp_engine = NLPEngine()
    safety_processor = SafetyProcessor()
    test_messages = [
        "What are the emergency protocols for chemical spills?",
        "How do I handle a gas leak?",
        "What PPE is needed for corrosive materials?",
        "Tell me about risk assessment for flammable liquids"
    ]
    for message in test_messages:
        intent = nlp_engine.extract_intent(message)
        response = safety_processor.generate_chat_response(message, intent)
        logger.info(f"Message: {message}\nIntent: {intent}\nResponse: {response}\n{'-'*40}")

if __name__ == "__main__":
    test_chat_responses()
