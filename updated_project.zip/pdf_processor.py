import os
import json
import logging
import time
import pickle
from typing import List, Dict, Any
import warnings
try:
    from pypdf import PdfReader
    HAS_PDF_SUPPORT = True
except ImportError:
    HAS_PDF_SUPPORT = False
    warnings.warn("PyPDF not available.")
try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    ADVANCED_FEATURES = True
except ImportError:
    ADVANCED_FEATURES = False
    warnings.warn("scikit-learn not available.")
import numpy as np
import faiss
from models import SafetyDocument

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

PDF_DIRS = {
    'protocol': 'data/pdfs/protocols',
    'incident_report': 'data/pdfs/incidents',
    'guideline': 'data/pdfs/guidelines',
    'reference': 'data/pdfs'
}
VECTOR_STORE_DIR = 'data/vector_store'
os.makedirs(VECTOR_STORE_DIR, exist_ok=True)
METADATA_FILE = os.path.join(VECTOR_STORE_DIR, 'document_metadata.json')
VECTORIZER_FILE = os.path.join(VECTOR_STORE_DIR, 'tfidf_vectorizer.pkl')
VECTOR_MATRIX_FILE = os.path.join(VECTOR_STORE_DIR, 'document_vectors.npy')
FAISS_INDEX_FILE = os.path.join(VECTOR_STORE_DIR, 'faiss_index.bin')

class PDFProcessor:
    def __init__(self):
        self.documents = []
        self.document_metadata = {}
        for dir_path in PDF_DIRS.values():
            os.makedirs(dir_path, exist_ok=True)
        self.vectorizer = None
        self.index = None
        self.document_vectors = None
        if ADVANCED_FEATURES:
            self.vectorizer = TfidfVectorizer(stop_words='english', max_features=5000, ngram_range=(1,2))
            self._load_or_create_vector_store()
        else:
            self._load_metadata()
        logger.info(f"PDFProcessor initialized with advanced features: {ADVANCED_FEATURES}")

    def extract_text_from_pdf(self, pdf_path: str) -> str:
        if not HAS_PDF_SUPPORT:
            logger.warning(f"PDF support not available for {pdf_path}")
            return ""
        try:
            reader = PdfReader(pdf_path)
            text = ""
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
            return text.strip()
        except Exception as e:
            logger.error(f"Error extracting text from {pdf_path}: {e}")
            return ""

    def process_pdf_directory(self) -> int:
        new_docs = 0
        for doc_type, dir_path in PDF_DIRS.items():
            for filename in os.listdir(dir_path):
                if not filename.lower().endswith('.pdf'):
                    continue
                filepath = os.path.join(dir_path, filename)
                doc_id = f"{doc_type}_{filename}"
                if doc_id in self.document_metadata:
                    continue
                text = self.extract_text_from_pdf(filepath)
                if not text:
                    continue
                new_docs += 1
                self.documents.append(text)
                creation_time = os.path.getctime(filepath)
                self.document_metadata[doc_id] = {
                    'id': doc_id,
                    'title': filename.replace('.pdf',''),
                    'document_type': doc_type,
                    'filepath': filepath,
                    'created_at': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(creation_time)),
                    'text_length': len(text),
                    'text_preview': text[:200] + ("..." if len(text)>200 else "")
                }
        if new_docs > 0 and ADVANCED_FEATURES:
            self._update_vector_store()
            logger.info(f"Added {new_docs} new documents to vector store.")
        else:
            logger.info("No new documents found.")
        return new_docs

    def _load_or_create_vector_store(self):
        if os.path.exists(METADATA_FILE) and os.path.exists(VECTORIZER_FILE) and os.path.exists(VECTOR_MATRIX_FILE) and os.path.exists(FAISS_INDEX_FILE):
            try:
                with open(METADATA_FILE, 'r') as f:
                    self.document_metadata = json.load(f)
                with open(VECTORIZER_FILE, 'rb') as f:
                    self.vectorizer = pickle.load(f)
                self.document_vectors = np.load(VECTOR_MATRIX_FILE)
                self.index = faiss.read_index(FAISS_INDEX_FILE)
                logger.info(f"Loaded vector store with {len(self.document_metadata)} documents.")
                return
            except Exception as e:
                logger.error(f"Error loading vector store: {e}")
        self.document_metadata = {}
        d = 5000
        self.index = faiss.IndexFlatL2(d)
        self.document_vectors = np.zeros((0, d))
        logger.info("Created new vector store.")

    def _update_vector_store(self):
        if not self.documents:
            logger.warning("No documents to vectorize.")
            return
        self._save_metadata()
        vectors = self.vectorizer.fit_transform(list(self.documents))
        vectors_dense = vectors.toarray().astype('float32')
        d = vectors_dense.shape[1]
        self.index = faiss.IndexFlatL2(d)
        self.index.add(vectors_dense)
        self.document_vectors = vectors_dense
        self._save_vector_store()

    def _save_metadata(self):
        try:
            with open(METADATA_FILE, 'w') as f:
                json.dump(self.document_metadata, f)
            logger.info(f"Metadata saved for {len(self.document_metadata)} documents.")
        except Exception as e:
            logger.error(f"Error saving metadata: {e}")

    def _save_vector_store(self):
        try:
            self._save_metadata()
            with open(VECTORIZER_FILE, 'wb') as f:
                pickle.dump(self.vectorizer, f)
            np.save(VECTOR_MATRIX_FILE, self.document_vectors)
            faiss.write_index(self.index, FAISS_INDEX_FILE)
            logger.info("Vector store saved.")
        except Exception as e:
            logger.error(f"Error saving vector store: {e}")

    def _load_metadata(self):
        if os.path.exists(METADATA_FILE):
            try:
                with open(METADATA_FILE, 'r') as f:
                    self.document_metadata = json.load(f)
                logger.info(f"Loaded metadata for {len(self.document_metadata)} documents.")
            except Exception as e:
                logger.error(f"Error loading metadata: {e}")
                self.document_metadata = {}
        else:
            logger.info("No metadata found, starting fresh.")
            self.document_metadata = {}

    def search(self, query: str, top_n: int = 5) -> List[Dict[str, Any]]:
        if ADVANCED_FEATURES and self.vectorizer and self.index is not None and self.document_vectors is not None and self.document_vectors.shape[0] > 0:
            query_vector = self.vectorizer.transform([query]).toarray().astype('float32')
            distances, indices = self.index.search(query_vector, top_n)
            results = []
            doc_ids = list(self.document_metadata.keys())
            for i, idx in enumerate(indices[0]):
                if idx < 0 or idx >= len(doc_ids):
                    continue
                doc_id = doc_ids[idx]
                distance = float(distances[0][i])
                similarity = 1.0 / (1.0 + distance)
                result = self.document_metadata[doc_id].copy()
                result["similarity"] = similarity
                results.append(result)
            return results
        query_terms = query.lower().split()
        results = []
        for doc_id, metadata in self.document_metadata.items():
            title = metadata.get("title", "").lower()
            preview = metadata.get("text_preview", "").lower()
            match_count = sum(1 for term in query_terms if term in title or term in preview)
            if match_count > 0:
                similarity = match_count / len(query_terms)
                result = metadata.copy()
                result["similarity"] = similarity
                results.append(result)
        results.sort(key=lambda x: x["similarity"], reverse=True)
        return results[:top_n]

    def get_document_by_id(self, doc_id: str) -> Dict[str, Any]:
        if doc_id in self.document_metadata:
            metadata = self.document_metadata[doc_id].copy()
            filepath = metadata.get("filepath")
            metadata["full_text"] = self.extract_text_from_pdf(filepath)
            return metadata
        return {}

    def get_text_chunk(self, doc_id: str, max_chars: int = 1000) -> str:
        doc = self.get_document_by_id(doc_id)
        text = doc.get("full_text", "")
        return text[:max_chars] + ("..." if len(text) > max_chars else "")

def get_pdf_processor():
    return PDFProcessor()
