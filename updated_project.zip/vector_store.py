import logging
import json
import os
import re
from collections import Counter
logger = logging.getLogger(__name__)

class VectorStore:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.incident_reports = self._load_incident_reports()
        self.processed_incidents = []
        for incident in self.incident_reports:
            text = f"{incident.get('title', '')} {incident.get('description', '')}"
            words = set(self._tokenize_text(text))
            self.processed_incidents.append({"incident": incident, "words": words})
        self.logger.info(f"VectorStore initialized with {len(self.incident_reports)} incidents")

    def _tokenize_text(self, text):
        return re.findall(r'\b\w+\b', text.lower())

    def _load_incident_reports(self):
        try:
            with open('data/pdfs/incident_reports.json', 'r') as f:
                data = json.load(f)
                return data.get("incidents", [])
        except Exception as e:
            self.logger.warning("Incident reports file not found or error occurred.")
            return []

    def find_similar_incidents(self, description, top_k=5):
        from collections import Counter
        query_tokens = set(self._tokenize_text(description))
        token_counts = Counter(self._tokenize_text(description))
        scored_incidents = []
        for proc in self.processed_incidents:
            common = query_tokens.intersection(proc["words"])
            if common:
                score = sum(token_counts[t] for t in common) / len(query_tokens)
                incident_copy = proc["incident"].copy()
                incident_copy["similarity_score"] = score
                incident_copy["matching_terms"] = list(common)
                scored_incidents.append(incident_copy)
        scored_incidents.sort(key=lambda x: x["similarity_score"], reverse=True)
        return scored_incidents[:top_k]
