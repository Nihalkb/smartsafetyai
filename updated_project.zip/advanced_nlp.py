"""
Advanced NLP Module - Provides integration with modern NLP models.
This module supports embedding generation using SentenceTransformers or HuggingFace Transformers.
"""
import os
import logging
import time
from functools import lru_cache

try:
    from sentence_transformers import SentenceTransformer
    HAS_SENTENCE_TRANSFORMERS = True
except ImportError:
    HAS_SENTENCE_TRANSFORMERS = False

try:
    from transformers import AutoModel, AutoTokenizer
    import torch
    HAS_TRANSFORMERS = True
except ImportError:
    HAS_TRANSFORMERS = False

logger = logging.getLogger(__name__)

class AdvancedNLP:
    def __init__(self):
        self.embedding_model = None
        self.tokenizer = None
        self.embedding_cache = {}
        self.cache_timestamp = {}
        self._init_embedding_model()
        logger.info("AdvancedNLP initialized.")

    def _init_embedding_model(self):
        if HAS_SENTENCE_TRANSFORMERS:
            try:
                self.embedding_model = SentenceTransformer("all-MiniLM-L6-v2")
                logger.info("Initialized SentenceTransformer model.")
                return
            except Exception as e:
                logger.error(f"Error initializing SentenceTransformer: {e}")
        if HAS_TRANSFORMERS:
            try:
                model_name = "sentence-transformers/all-MiniLM-L6-v2"
                self.tokenizer = AutoTokenizer.from_pretrained(model_name)
                self.embedding_model = AutoModel.from_pretrained(model_name)
                logger.info("Initialized HuggingFace embedding model.")
                return
            except Exception as e:
                logger.error(f"Error initializing HuggingFace model: {e}")
        logger.warning("No embedding model available.")

    def get_embedding(self, text: str):
        if text in self.embedding_cache:
            return self.embedding_cache[text]
        if self.embedding_model is None:
            return None
        try:
            if HAS_SENTENCE_TRANSFORMERS:
                embedding = self.embedding_model.encode(text)
            elif HAS_TRANSFORMERS:
                encoded_input = self.tokenizer(text, return_tensors='pt', truncation=True, padding=True)
                with torch.no_grad():
                    model_output = self.embedding_model(**encoded_input)
                embedding = model_output.last_hidden_state.mean(dim=1).squeeze().tolist()
            else:
                return None
            self.embedding_cache[text] = embedding
            self.cache_timestamp[text] = time.time()
            return embedding
        except Exception as e:
            logger.error(f"Error generating embedding: {e}")
            return None

    def rank_documents(self, query: str, documents, content_field="content", top_n=5):
        query_emb = self.get_embedding(query)
        if query_emb is None:
            return []
        results = []
        for doc in documents:
            doc_text = doc.get(content_field, "")
            doc_emb = self.get_embedding(doc_text)
            if doc_emb is None:
                continue
            try:
                import numpy as np
                sim = np.dot(query_emb, doc_emb) / (np.linalg.norm(query_emb) * np.linalg.norm(doc_emb))
            except Exception:
                sim = 0
            doc_copy = doc.copy()
            doc_copy["similarity"] = sim
            results.append(doc_copy)
        results.sort(key=lambda x: x["similarity"], reverse=True)
        return results[:top_n]

def get_advanced_nlp():
    return AdvancedNLP()
